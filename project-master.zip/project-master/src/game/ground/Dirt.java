package game.ground;

import edu.monash.fit2099.engine.positions.Ground;

/**
 * A class that represents bare dirt.
 */
public class Dirt extends Ground {

  /**
   * A constructor for the Dirt class
   */
  public Dirt() {
    super('.');
  }
}
