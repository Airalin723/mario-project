package edu.monash.fit2099.demo.mars;

public enum DemoCapabilities {
	SPACETRAVELLER
}
